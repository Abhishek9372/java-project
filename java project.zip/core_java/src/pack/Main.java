package pack;

public class Main {
public void msg() {
	System.out.println("hello");
}
}
