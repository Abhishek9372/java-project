package java_static_block;

class A2 {
	static {
		System.out.println("static block is invoked");
	}
}

public class Main {
	public static void main(String args[]) {
		System.out.println("Hello main");
	}
}
