package Typecasting;

public class Simple {
public static void main(String[] args) {
	float f=10.5f;
	
	int a=(int)f;
	System.out.println(f);
	System.out.println(a);
	
}
}
