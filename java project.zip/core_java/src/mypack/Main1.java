package mypack;
//package import;

import pack. *;
public class Main1 {
public static void main(String[] args) {
	Main obj = new Main();
	obj.msg();
}
}
