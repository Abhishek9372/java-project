package Array;

public class String {
public static void main(String[] args) {
	char[] ch={'A','B','H','I',};
	String s=new String();
}
}
