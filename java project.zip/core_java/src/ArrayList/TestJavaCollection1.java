package ArrayList;

import java.util.*;

public class TestJavaCollection1 {
	public static void main(String args[]) {
		ArrayList<String> list = new ArrayList<String>();// Creating arraylist
		list.add("Anjana");// Adding object in arraylist
		list.add("Sanjana");
		list.add("Amruta");
		list.add("Archana");
        //Traversing list through Iterator
		Iterator itr = list.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
