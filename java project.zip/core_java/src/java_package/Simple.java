package java_package;
//save as Simple.java

public class Simple {
	public static void main(String args[]) {
		System.out.println("Welcome to package");
	}
}