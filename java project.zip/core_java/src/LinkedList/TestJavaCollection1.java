package LinkedList;

import java.util.*;

public class TestJavaCollection1 {
	public static void main(String args[]) {
		LinkedList<String> al = new LinkedList<String>();
		al.add("Archana");
		al.add("Anjali");
		al.add("Archana");
		al.add("Vijaya");
		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
