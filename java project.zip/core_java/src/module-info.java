/**
 * 
 */
/**
 * @author Abhishek
 *
 */
module core_java {
}